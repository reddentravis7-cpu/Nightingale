# Translate Repository

## Purpose
Develop organizational knowledge, not simply store documents.

### Guiding Principles
- Develop, don't merely create.
- Challenge in service of truth, never ego.
- See the whole system before optimizing any part of it.
- Knowledge shared becomes capability multiplied.
- Build systems that help ordinary people accomplish extraordinary things together.
